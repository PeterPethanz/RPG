﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using Engine.Vizuální_Modely;
using Engine.EventArgs;
using Engine.Modely;


namespace WPF_Kód
{
    /// <summary>
    /// Interakční logika pro MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private readonly Prostředí _prostředí = new Prostředí();
        private readonly Dictionary<Key, Action> _userInputAction = new Dictionary<Key, Action>();
        public MainWindow()
        {
            InitializeComponent();
            InicializaceUživatelovaTlačítkaNaAkci();

            _prostředí.NaZprávuVypiš += NaHerníZprávuVypiš;

            DataContext = _prostředí;
        }
        private void Button_Click_Sever(object sender, RoutedEventArgs e)
        {
            _prostředí.PohybSever();
        }

        private void Button_Click_Západ(object sender, RoutedEventArgs e)
        {
            _prostředí.PohybZápad();
        }

        private void Button_Click_Východ(object sender, RoutedEventArgs e)
        {
            _prostředí.PohybVýchod();
        }

        private void Button_Click_Jih(object sender, RoutedEventArgs e)
        {
            _prostředí.PohybJih();
        }

        private void Button_Click_ZaútočitNaMonstrum(object sender, RoutedEventArgs e)
        {
            _prostředí.ZaútočAktuálníMonstrum();
        }
        private void Button_Click_PoužítAktuálníPoužitelné(object sender, RoutedEventArgs e)
        {
            _prostředí.PoužítAktuálníPoužitelné();
        }
        private void NaHerníZprávuVypiš(object sender, ZprávyHryEventArgs e)
        {
            HerníZprávy.Document.Blocks.Add(new Paragraph(new Run(e.Zpráva)));
            HerníZprávy.ScrollToEnd();
        }
        private void NaKlik_Obchod_Obraz(object sender, RoutedEventArgs e)
        {
           if(_prostředí.AktuálníObchodník !=null)
            {
                Obchod_Obraz obchod_Obraz = new Obchod_Obraz();
                obchod_Obraz.Owner = this;
                obchod_Obraz.DataContext = _prostředí;
                obchod_Obraz.ShowDialog();
            }
        }
        private void Button_Click_Vytvořit(object sender, RoutedEventArgs e)
        {
            Recept recept = ((FrameworkElement)sender).DataContext as Recept;
            _prostředí.VytvořPředmětPoužitím(recept);
        }

        private void InicializaceUživatelovaTlačítkaNaAkci()
        {
            _userInputAction.Add(Key.W, () => _prostředí.PohybSever());
            _userInputAction.Add(Key.A, () => _prostředí.PohybZápad());
            _userInputAction.Add(Key.S, () => _prostředí.PohybJih());
            _userInputAction.Add(Key.D, () => _prostředí.PohybVýchod());
            _userInputAction.Add(Key.Z, () => _prostředí.ZaútočAktuálníMonstrum());
            _userInputAction.Add(Key.C, () => _prostředí.PoužítAktuálníPoužitelné());
            _userInputAction.Add(Key.I, () => NastavTabFocusNa("InventářTabItem"));
            _userInputAction.Add(Key.U, () => NastavTabFocusNa("ÚkolyTabItem"));
            _userInputAction.Add(Key.R, () => NastavTabFocusNa("RecptyTabItem"));
            _userInputAction.Add(Key.E, () => NaKlik_Obchod_Obraz(this, new RoutedEventArgs()));

        }
        private void MainWindow_OnKeyDown(object sender, KeyEventArgs e)
        {
            if (_userInputAction.ContainsKey(e.Key))
            {
                _userInputAction[e.Key].Invoke();
            }
        }
        private void NastavTabFocusNa(string tabName)
        {
            foreach (object item in DataHráčeTabControl.Items)
            {
                if (item is TabItem tabItem)
                {
                    if (tabItem.Name == tabName)
                    {
                        tabItem.IsSelected = true;
                        return;
                    }
                }
            }
        }

    }
}
