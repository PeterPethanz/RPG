﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Engine.Modely;
using Engine.Vizuální_Modely;

namespace WPF_Kód
{
    /// <summary>
    /// Interakční logika pro Obchod_Obraz.xaml
    /// </summary>
    public partial class Obchod_Obraz : Window
    {
        public Prostředí prostředí => DataContext as Prostředí;
        public Obchod_Obraz()
        {
            InitializeComponent();
        }
        private void NaKlik_Prodat(object sender, RoutedEventArgs e)
        {
            SeskupenýInventář seskupenýInventář = ((FrameworkElement)sender).DataContext as SeskupenýInventář;

            if(seskupenýInventář != null)
            {
                prostředí.AktuálníHráč.DostatZlatky(seskupenýInventář.Předmět.Cena);
                prostředí.AktuálníObchodník.PřidatPředmětDoInventáře(seskupenýInventář.Předmět);
                prostředí.AktuálníHráč.OdstranitPředmětZInventáře(seskupenýInventář.Předmět);
            }
        }
        private void NaKlik_Koupit(object sender, RoutedEventArgs e)
        {
            SeskupenýInventář seskupenýInventář = ((FrameworkElement)sender).DataContext as SeskupenýInventář;

            if(seskupenýInventář !=null)
            {
                if(prostředí.AktuálníHráč.Zlatky >= seskupenýInventář.Předmět.Cena)
                {
                    prostředí.AktuálníHráč.UtratitZlatky(seskupenýInventář.Předmět.Cena);
                    prostředí.AktuálníObchodník.OdstranitPředmětZInventáře(seskupenýInventář.Předmět);
                    prostředí.AktuálníHráč.PřidatPředmětDoInventáře(seskupenýInventář.Předmět);
                }
                else
                {
                    MessageBox.Show("Nemáš dostatek zlatek.");
                }
            }
        }
    
        private void NaKlik_Zavřít(object sender, RoutedEventArgs e)
        {
            Close();
        }
    
    }
}
