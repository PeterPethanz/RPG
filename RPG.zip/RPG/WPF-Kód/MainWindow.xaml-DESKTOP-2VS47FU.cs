﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Engine.Vizuální_Modely;
using Engine.EventArgs;

namespace WPF_Kód
{
    /// <summary>
    /// Interakční logika pro MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private readonly Prostředí _prostředí = new Prostředí();
        public MainWindow()
        {
            InitializeComponent();

            _prostředí.NaZprávuVypiš += NaHerníZprávuVypiš;

            DataContext = _prostředí;
        }
        private void Button_Click_Sever(object sender, RoutedEventArgs e)
        {
            _prostředí.PohybSever();
        }

        private void Button_Click_Západ(object sender, RoutedEventArgs e)
        {
            _prostředí.PohybZápad();
        }

        private void Button_Click_Východ(object sender, RoutedEventArgs e)
        {
            _prostředí.PohybVýchod();
        }

        private void Button_Click_Jih(object sender, RoutedEventArgs e)
        {
            _prostředí.PohybJih();
        }
        
        private void Button_Click_ZaútočitNaMonstrum(object sender, RoutedEventArgs e)
        {
            _prostředí.ZaútočAktuálníMonstrum();
        }
        private void NaKlik_PoužítAktuálníSpotřebné(object)
        private void NaHerníZprávuVypiš(object sender, ZprávyHryEventArgs e)
        {
            HerníZprávy.Document.Blocks.Add(new Paragraph(new Run(e.Zpráva)));
            HerníZprávy.ScrollToEnd();
        }
        private void NaKlik_Obchod_Obraz(object sender, RoutedEventArgs e)
        {
            Obchod_Obraz obchod_Obraz = new Obchod_Obraz();
            obchod_Obraz.Owner = this;
            obchod_Obraz.DataContext = _prostředí;
            obchod_Obraz.ShowDialog();
        }


    }
}
