﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Engine.Vizuální_Modely;

namespace TestEngine.Vizuální_Modely
{
    [TestClass]
    public class TestHry_Prostředí
    {
        [TestMethod]
        public void TestVytvořitProstředí()
        {
            Prostředí prostředí = new Prostředí();

            Assert.IsNotNull(prostředí.AktuálníHráč);
            Assert.AreEqual("Smrtící Fontána", prostředí.AktuálníLokace.Jméno);
        }
        [TestMethod]
        public void TestujHráčovoPohybDomůAJeVyléčenNaZabití()
        {
            Prostředí prostředí = new Prostředí();

            prostředí.AktuálníHráč.DostatPoškození(900);

            Assert.AreEqual("Tvůj Domov", prostředí.AktuálníLokace.Jméno);
            Assert.AreEqual(prostředí.AktuálníHráč.Úroveň * 10, prostředí.AktuálníHráč.AktuálníŽivoty);
        }
    
    }
}
