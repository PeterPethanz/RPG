﻿
namespace Engine.EventArgs
{
    public class ZprávyHryEventArgs : System.EventArgs
    {
        public string Zpráva { get; set; }

        public ZprávyHryEventArgs(string zpráva)
        {
            Zpráva = zpráva;
        }
    }
}
