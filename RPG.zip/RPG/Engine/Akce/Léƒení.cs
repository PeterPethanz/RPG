﻿using System;
using Engine.Modely;
namespace Engine.Akce
{
    public class Léčení :ZákladníAkce , IAkce
    {
        private readonly int _životyNaLéčení;

        public Léčení(HerníPředměty předmětVPoužití, int životyNaLéčení) : base(předmětVPoužití)
        {
            if(předmětVPoužití.Kategorie != HerníPředměty.KategoriePředmětů.Použitelné)
            {
                throw new ArgumentException($"{předmětVPoužití.Jméno} není spotřebný");
            }
            _životyNaLéčení = životyNaLéčení;
        }
        public void Execute(Žijící_entita působící, Žijící_entita způsobený)
        {
            string působícíJméno = (působící is Hráč) ? "" : $"{působící.Jméno.ToLower()}";
            string způsobenýJméno = (způsobený is Hráč) ? "Jsi se" : $"{způsobený.Jméno.ToLower()}";
            if (_životyNaLéčení > 4)
            {

                Výsledek($"{působícíJméno} Vyléčil {způsobenýJméno} za {_životyNaLéčení} bodů životů.");
                
                způsobený.Léčení(_životyNaLéčení);
            }
            else
                Výsledek($"{působícíJméno} Vyléčil {způsobenýJméno} za {_životyNaLéčení} body životů.");
            způsobený.Léčení(_životyNaLéčení);
        }
    }
}
