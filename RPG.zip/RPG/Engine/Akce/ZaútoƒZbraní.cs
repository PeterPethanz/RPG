﻿using System;
using Engine.Modely;

namespace Engine.Akce
{
    public class ZaútočZbraní :ZákladníAkce , IAkce
    {
        private readonly HerníPředměty _zbraň;
        private readonly int _maximálníPoškození;
        private readonly int _minimálníPoškození;
        public ZaútočZbraní(HerníPředměty předmětVPoužití, int minimálníPoškození, int maximálníPoškození) : base(předmětVPoužití)
            
        {
            if (_předmětVPoužití.Kategorie != HerníPředměty.KategoriePředmětů.Zbraň)
            {
                throw new ArgumentException($"{_předmětVPoužití.Jméno} není zbraň");
            }
            if (_minimálníPoškození < 0)
            {
                throw new ArgumentException("minimálníPoškození musí být 0 nebo více");
            }
            if (_maximálníPoškození < _minimálníPoškození)
            {
                throw new ArgumentException("maximálníPoškození musí být >= minimálníPoškození");
            }
            _maximálníPoškození = maximálníPoškození;
            _minimálníPoškození = minimálníPoškození;
        }
        public void Execute(Žijící_entita působící, Žijící_entita způsobený)
        {
            int poškození = RngGenerátor.HodnotaMezi(_minimálníPoškození, _maximálníPoškození);

            string působícíJméno = (působící is Hráč) ?$""   : $"{působící.Jméno.ToLower()}";
            string způsobenýJméno = (způsobený is Hráč) ? "Byl jsi zasažen" : $"{způsobený.Jméno.ToLower()}";
            
            if (poškození == 0)
            {
                
                Výsledek($" {působícíJméno} Nezasáhl {způsobenýJméno}.");
            }
             else
             {
                if(poškození<5)
                {
                    Výsledek($" {působícíJméno}  {způsobenýJméno} za {poškození} body poškození.");
                    způsobený.DostatPoškození(poškození);
                }
               
             }

        }
    }
}

