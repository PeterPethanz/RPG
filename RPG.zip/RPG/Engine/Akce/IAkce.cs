﻿using System;
using Engine.Modely;

namespace Engine.Akce
{
    public interface IAkce
    {
        event EventHandler<string> NaAkciProvedeno;
        void Execute(Žijící_entita působící, Žijící_entita způsobený);
    }
}
