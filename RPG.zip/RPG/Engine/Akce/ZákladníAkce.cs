﻿using System;
using Engine.Modely;

namespace Engine.Akce
{
    public abstract class ZákladníAkce
    {
        protected readonly HerníPředměty _předmětVPoužití;

        public event EventHandler<string> NaAkciProvedeno;

        protected ZákladníAkce(HerníPředměty předmětVPoužití)
        {
            _předmětVPoužití = předmětVPoužití;
        }
        protected void Výsledek(string výsledek)
        {
            NaAkciProvedeno?.Invoke(this, výsledek);
        }
    }
}
