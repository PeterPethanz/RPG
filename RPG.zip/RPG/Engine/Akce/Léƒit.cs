﻿using System;
using Engine.Modely;

namespace Engine.Akce
{
    public class Léčit : IAkce
    {
        private readonly HerníPředměty _předměty;
        private readonly int _zdravíNaLéčení;

        public event EventHandler<string> NaAkciProvedeno;

        public Léčit(HerníPředměty předměty, int zdravíNaLéčení)
        {
            if (předměty.Kategorie != HerníPředměty.KategoriePředmětů.Spotřebné)
            {
                throw new ArgumentException($"{předměty.Jméno} není Spotřebný předmět");
            }
            _předměty = předměty;
            _zdravíNaLéčení = zdravíNaLéčení;

        }
        public void Execute(Žijící_entita působící, Žijící_entita způsobený)
        {
            string působícíJméno = (působící is Hráč) ? "Ty" : $"{působící.Jméno.ToLower()}";
            string způsobenýJméno = (způsobený is Hráč) ? " sobě" : $"{způsobený.Jméno.ToLower()}";

            Výsledek($"{působícíJméno} vyléčil {způsobenýJméno} za {_zdravíNaLéčení} bod {(_zdravíNaLéčení > 1 ? "ů" : "")}léčení.");
            působící.Léčení(_zdravíNaLéčení);
        }
        private void Výsledek(string výsledek)
        {
            NaAkciProvedeno?.Invoke(this, výsledek);
        }
    }
}
