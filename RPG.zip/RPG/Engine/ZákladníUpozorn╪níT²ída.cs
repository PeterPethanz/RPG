﻿using System.Runtime.CompilerServices;
using System.ComponentModel;

namespace Engine
{
    public class ZákladníUpozorněníTřída : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
