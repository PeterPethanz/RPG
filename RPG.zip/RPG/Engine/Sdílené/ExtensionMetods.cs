﻿using System;
using System.Xml;

namespace Engine.Sdílené
{
    public static class ExtensionMetods
    {
        public static int AtributyJakoInt(this XmlNode node, string jménoAtributu)
        {
            return Convert.ToInt32(node.AtributyJakoString(jménoAtributu));
        }
        public static string AtributyJakoString(this XmlNode node, string jménoAtributu)
        {
            XmlAttribute attribute = node.Attributes?[jménoAtributu];

            if (attribute == null)
            {
                throw new ArgumentException($"atribut {jménoAtributu} neexistuje.");
            }
            return attribute.Value;
        }
    }
}   
