﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Collections.ObjectModel;

namespace Engine.Modely
{
    public class Hráč : Žijící_entita
    {
        #region Properties

        private string _třídaPostavy;
        private int _zkušenosti;
        public string TřídaPostavy 
        {
            get { return _třídaPostavy; }
            set 
            {
                _třídaPostavy= value;
                OnPropertyChanged();
            } 
        }
        public int Zkušenosti 
        {
            get { return _zkušenosti; }
            private set 
            {
                _zkušenosti= value;
                OnPropertyChanged();
                NastavitÚroveňMaximálníchŽivotů();
            } 
        }
        public ObservableCollection<StatusÚkolů> Úkoly { get; }
        public ObservableCollection<Recept> Recepty { get; }
        #endregion
        public event EventHandler NaZvýšeníÚrovně;

        public Hráč(string jméno, string třídaPostavy, int zkušenosti, int maximálníŽivoty, int aktuálníŽivoty, int zlatky) :
            base(jméno,maximálníŽivoty,aktuálníŽivoty,zlatky)
        {
            TřídaPostavy = třídaPostavy;
            Zkušenosti = zkušenosti;
            
            Úkoly = new ObservableCollection<StatusÚkolů>();
            Recepty = new ObservableCollection<Recept>();
        }
        
        
        public void PřidatZkušenosti(int zkušenosti)
        {
            Zkušenosti += zkušenosti;
        }
        public void NaučitRecept(Recept recept)
        {
            if(!Recepty.Any(r => r.ID == recept.ID))
            {
                Recepty.Add(recept);
            }
        }
        private void NastavitÚroveňMaximálníchŽivotů()
        {
            int základníÚroveň = Úroveň;
            Úroveň = (Zkušenosti / 100) + 1;
            if (Úroveň != základníÚroveň)
            {
                MaximálníŽivoty = Úroveň * 10;
                

                NaZvýšeníÚrovně?.Invoke(this, System.EventArgs.Empty);
            }
        }
    }
}
