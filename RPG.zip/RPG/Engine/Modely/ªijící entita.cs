﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Collections.ObjectModel;

namespace Engine.Modely
{
    public abstract class Žijící_entita :ZákladníUpozorněníTřída
    {
        #region Properties
        private string _jméno;
        private int _aktuálníŽivoty;
        private int _maximálníŽivoty;
        private int _zlatky;
        private int _úroveň;
        private HerníPředměty _aktuálníZbraň;
        private HerníPředměty _aktuálníPoužitelné;


        public string Jméno
        {
            get { return _jméno;}
             private set 
            {
                _jméno=value;
                OnPropertyChanged();
            }
        }
         public int AktuálníŽivoty
        {
            get { return _aktuálníŽivoty;}
            private set 
            { 
                _aktuálníŽivoty =value;
                OnPropertyChanged();
            }
        }
        public int MaximálníŽivoty
        {
            get { return _maximálníŽivoty; }
            protected set 
            { 
                _maximálníŽivoty =value;
                OnPropertyChanged();
            }
        }
        public int Zlatky
        {
            get { return _zlatky;}
            private set 
            { 
                _zlatky = value;
                OnPropertyChanged();
            }
        }
        public int Úroveň 
        {
            get { return _úroveň; }
            protected set 
            { 
                _úroveň = value;
                OnPropertyChanged();
            } 
         
        }
        public HerníPředměty AktuálníZbraň
        {
            get { return _aktuálníZbraň; }
            set
            {
                if(_aktuálníZbraň != null)
                {
                    _aktuálníZbraň.Akce.NaAkciProvedeno -= VypišNaAkciProvedenoEvent;
                }
                _aktuálníZbraň = value;
                if(_aktuálníZbraň !=null)
                {
                    _aktuálníZbraň.Akce.NaAkciProvedeno += VypišNaAkciProvedenoEvent;
                }
                OnPropertyChanged();
            }
            
        }
        public HerníPředměty AktuálníPoužitelné
        {
            get => _aktuálníPoužitelné;
            set 
            { 
                if(_aktuálníPoužitelné !=null)
                {
                    _aktuálníPoužitelné.Akce.NaAkciProvedeno -= VypišNaAkciProvedenoEvent;
                }
                _aktuálníPoužitelné = value;
                if(_aktuálníPoužitelné != null)
                {
                    _aktuálníPoužitelné.Akce.NaAkciProvedeno += VypišNaAkciProvedenoEvent;
                }
                OnPropertyChanged();
            }
        }
        public ObservableCollection<HerníPředměty> Inventář { get; }

        public ObservableCollection<SeskupenýInventář> SeskupenýInventář { get; }

        

        public List<HerníPředměty> Zbraně =>
            Inventář.Where(i => i.Kategorie == HerníPředměty.KategoriePředmětů.Zbraň).ToList();
        public List<HerníPředměty> Použitelnés =>
            Inventář.Where(i => i.Kategorie == HerníPředměty.KategoriePředmětů.Použitelné).ToList();


        public bool MáPoužitelné => Použitelnés.Any();
        public bool JeMrtvý => AktuálníŽivoty <= 0;
        #endregion
        public event EventHandler<string> NaAkciProvedeno;
        public event EventHandler NaZabití;
        protected Žijící_entita(string jméno, int maximálníŽivoty, int aktuálníŽivoty, int zlatky, int úroveň = 1)
        {
            Jméno = jméno;
            MaximálníŽivoty = maximálníŽivoty;
            AktuálníŽivoty = aktuálníŽivoty;
            Zlatky = zlatky;
            Úroveň = úroveň;
            
            
            Inventář = new ObservableCollection<HerníPředměty>();
            SeskupenýInventář = new ObservableCollection<SeskupenýInventář>();
        }
        public void PoužítAktuálníZbraňNa(Žijící_entita způsobený)
        {
            AktuálníZbraň.ProvéstAkci(this, způsobený);
        }
        public void DostatPoškození(int PoškozeníŽivoty)
        {
            AktuálníŽivoty -= PoškozeníŽivoty;
            if(JeMrtvý)
            {
                AktuálníŽivoty = 0;
                VypišNaZabitíEvent();
            }
        }

        public void Léčení(int ŽivotyLéčení)
        {
            AktuálníŽivoty += ŽivotyLéčení;

            if(AktuálníŽivoty> MaximálníŽivoty)
            {
                AktuálníŽivoty = MaximálníŽivoty;
            }
        }
        public void PoužítAktuálníPoužitelné()
        {
            AktuálníPoužitelné.ProvéstAkci(this, this);
            OdstranitPředmětZInventáře(AktuálníPoužitelné);
        }
        public void KompletníLéčení()
        {
            AktuálníŽivoty = MaximálníŽivoty;
        }
        public void DostatZlatky(int MnožstvíZlatek)
        {
            Zlatky += MnožstvíZlatek;
        }
        public void UtratitZlatky (int MnožstvíZlatek)
        {
            if(MnožstvíZlatek>Zlatky)
            {
                throw new ArgumentOutOfRangeException($"{Jméno} máš jen {Zlatky} zlatek, a nemůže utratit {MnožstvíZlatek} zlatek.");
            }
            Zlatky -= MnožstvíZlatek;
        }
        public void PřidatPředmětDoInventáře(HerníPředměty předměty)
        {
            Inventář.Add(předměty);

            if(předměty.JeJedinečný )
            {
                SeskupenýInventář.Add(new SeskupenýInventář(předměty, 1));
            }
            else
            {
                if(!SeskupenýInventář.Any(si => si.Předmět.IDpředmětu == předměty.IDpředmětu))
                {
                    SeskupenýInventář.Add(new SeskupenýInventář(předměty, 0));
                }
                SeskupenýInventář.First(si => si.Předmět.IDpředmětu == předměty.IDpředmětu).Množství++;
            }
            OnPropertyChanged(nameof(Zbraně));
            OnPropertyChanged(nameof(Použitelnés));
            OnPropertyChanged(nameof(MáPoužitelné));
        }
        public void OdstranitPředmětZInventáře(HerníPředměty předměty)
        {
            Inventář.Remove(předměty);

            SeskupenýInventář seskupenýInventářOdstranit = předměty.JeJedinečný ?
                SeskupenýInventář.FirstOrDefault(si => si.Předmět == předměty) :
                SeskupenýInventář.FirstOrDefault(si => si.Předmět.IDpředmětu == předměty.IDpředmětu);
                


            if (seskupenýInventářOdstranit != null)
            {
                if(seskupenýInventářOdstranit.Množství== 1)
                {
                    SeskupenýInventář.Remove(seskupenýInventářOdstranit);
                }
                else
                {
                    seskupenýInventářOdstranit.Množství--;
                }
            }
            OnPropertyChanged(nameof(Zbraně));
            OnPropertyChanged(nameof(Použitelnés));
            OnPropertyChanged(nameof(MáPoužitelné));

        }
        public void OdstranitPředmětyZInventáře(List<MnožstvíPředmětů> množstvíPředmětů1)
        {
            foreach (MnožstvíPředmětů množstvíPředmětů in množstvíPředmětů1)
            {
                for (int p = 0; p < množstvíPředmětů.Množství; p++)
                {
                    OdstranitPředmětZInventáře(Inventář.First(předměty => předměty.IDpředmětu == množstvíPředmětů.IDpředmětu));
                }

            }
        }
        public bool MáVšechnyTytoPředměty(List<MnožstvíPředmětů> předmětů1)
        {
            foreach(MnožstvíPředmětů předmětů in předmětů1)
            {
                if(Inventář.Count(i => i.IDpředmětu == předmětů.IDpředmětu) <předmětů.Množství)
                {
                    return false;
                }
            }
            return true;
        }
        #region Privátní Funkce
        private void VypišNaZabitíEvent()
        {
            NaZabití?.Invoke(this, new System.EventArgs());
        }
        private void VypišNaAkciProvedenoEvent(object sender, string výsledek)
        {
            NaAkciProvedeno?.Invoke(this, výsledek);
        }


        #endregion
    }




}
