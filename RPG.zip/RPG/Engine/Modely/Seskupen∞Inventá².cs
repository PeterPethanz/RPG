﻿

namespace Engine.Modely
{
    public class SeskupenýInventář :ZákladníUpozorněníTřída
    {
        private HerníPředměty _předmět;
        private int _množství;

        public HerníPředměty Předmět
        {
            get { return _předmět; }
            set
            {
                _předmět = value;
                OnPropertyChanged(nameof(Předmět));
            }
        }
        public int Množství
        {
            get { return _množství; }
            set
            {
                _množství = value;
                OnPropertyChanged(nameof(Množství));
            }
        }
        public SeskupenýInventář(HerníPředměty předmět, int množství)
        {
            Předmět = předmět;
            Množství = množství;
        }
    
    
    }
}
