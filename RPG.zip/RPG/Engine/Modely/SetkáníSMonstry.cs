﻿namespace Engine.Modely
{
    public class SetkáníSMonstry
    {
        public int IDMonstra { get; }
        public int ŠanceNaSetkání { get; set; }

        public SetkáníSMonstry(int iDMonstra, int šanceNaSetkání)
        {
            IDMonstra = iDMonstra;
            ŠanceNaSetkání = šanceNaSetkání;
        }
    }
}
