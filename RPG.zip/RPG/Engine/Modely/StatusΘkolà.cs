﻿namespace Engine.Modely
{
    public class StatusÚkolů : ZákladníUpozorněníTřída
    {
        private bool _dokončen;
        public Úkoly ÚkolyHráče { get;}
        public bool Dokončen 
        {
            get { return _dokončen; }
            set 
            { 
                _dokončen = value;
                OnPropertyChanged();
            } 
        }

        public StatusÚkolů(Úkoly úkoly)
        {
            ÚkolyHráče = úkoly;
            Dokončen = false;
        }
    }
}
