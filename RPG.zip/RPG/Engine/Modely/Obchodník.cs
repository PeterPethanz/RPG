﻿

namespace Engine.Modely
{
    public class Obchodník :Žijící_entita
    {
        public int ID { get; }
        public Obchodník(int id,string jméno) : base (jméno, 9999, 9999, 9999)
        {
            ID = id;
        }
    }
}
