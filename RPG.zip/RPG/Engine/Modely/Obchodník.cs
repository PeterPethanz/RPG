﻿

namespace Engine.Modely
{
    public class Obchodník :Žijící_entita
    {
        public Obchodník(string jméno) : base (jméno, 9999, 9999, 9999)
        {
        }
    }
}
