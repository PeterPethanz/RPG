﻿using System.Collections.Generic;
using System.Linq;
using Engine.Stavby;


namespace Engine.Modely
{
    public class Lokace
    {
        public int SouřadniceX { get; }
        public int SouřadniceY { get; }
        public string Jméno { get; }
        public string Popis { get; }
        public string JménoObrázku { get; }
        public List<Úkoly> ÚkolyZdeKDispozici { get; } = new List<Úkoly>();

        public List<SetkáníSMonstry> MonstraZde { get; } =
            new List<SetkáníSMonstry>();

        public Obchodník ObchodníkZde { get; set; }
        public Lokace(int souřadniceX, int souřadniceY, string jméno, string popis, string jménoObrázku)
        {
            SouřadniceX = souřadniceX;
            SouřadniceY = souřadniceY;
            Jméno = jméno;
            Popis = popis;
            JménoObrázku = jménoObrázku;
        }

        public void PřidatMonstra(int iDMonstra, int šanceNaSetkání)
        {
            if(MonstraZde.Exists(m => m.IDMonstra == iDMonstra))
            {
                MonstraZde.First(m => m.IDMonstra == iDMonstra).ŠanceNaSetkání = šanceNaSetkání;
            }
            else
            {
                MonstraZde.Add(new SetkáníSMonstry(iDMonstra, šanceNaSetkání));
            }
        }
        public Monstra DostatMonstrum()
        {
            if(!MonstraZde.Any())
            {
                return null;
            }
            int totálníŠance = MonstraZde.Sum(m => m.ŠanceNaSetkání);

            int náhodnéČíslo = RngGenerátor.HodnotaMezi(1, totálníŠance);

            int celkovéMnožství = 0;

            foreach(SetkáníSMonstry setkáníSMonstry in MonstraZde)
            {
                celkovéMnožství += setkáníSMonstry.ŠanceNaSetkání;

                if(náhodnéČíslo <=celkovéMnožství)
                {
                    return Stavba_Monster.DostatMonstrum(setkáníSMonstry.IDMonstra);
                }
            }
            return Stavba_Monster.DostatMonstrum(MonstraZde.Last().IDMonstra);
        }
    }
}
