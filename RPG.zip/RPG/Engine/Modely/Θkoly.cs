﻿using System.Collections.Generic;

namespace Engine.Modely
{
    public class Úkoly
    {
        public int ID { get; }
        public string Jméno { get; }
        public string Popis { get; }

        public List<MnožstvíPředmětů> PředmětyKDokončení { get; }

        public int OdměnaZkušenosti { get; }
        public int OdměnaZlatky { get; }
        public List<MnožstvíPředmětů> OdměnaPředmět { get; }

        public Úkoly(int id, string jméno, string popis, List<MnožstvíPředmětů> předmětyKDokončení, int odměnaZkušenosti, int odměnaZlatky, List<MnožstvíPředmětů> odměnaPředmět)
        {
            ID = id;
            Jméno = jméno;
            Popis = popis;
            PředmětyKDokončení = předmětyKDokončení;
            OdměnaZkušenosti = odměnaZkušenosti;
            OdměnaZlatky = odměnaZlatky;
            OdměnaPředmět = odměnaPředmět;

        }
    }
}
