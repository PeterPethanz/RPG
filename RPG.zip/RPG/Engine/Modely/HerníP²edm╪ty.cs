﻿using Engine.Akce;

namespace Engine.Modely
{
    public class HerníPředměty
    {
        public enum KategoriePředmětů
        {
            Smíšené,
            Zbraň,
            Použitelné
        }

        public KategoriePředmětů Kategorie { get; }
        public int IDpředmětu { get;  }
        public string Jméno { get;  }
        public int Cena { get;  }
        public bool JeJedinečný { get;  }
        public IAkce Akce { get; set; }


        public HerníPředměty(KategoriePředmětů kategorie, int iDpředmětu, string jméno, int cena, bool jeJedinečný = false, IAkce akce = null)
        {
            Kategorie = kategorie;
            IDpředmětu = iDpředmětu;
            Jméno = jméno;
            Cena = cena;
            JeJedinečný = jeJedinečný;
            Akce = akce;
        }
       public void ProvéstAkci(Žijící_entita působící, Žijící_entita způsobený)
        {
            Akce?.Execute(působící, způsobený);
        }
        
        public HerníPředměty Klon()
        {
            return new HerníPředměty(Kategorie, IDpředmětu, Jméno, Cena, JeJedinečný, Akce);
        }
            
    }
}
