﻿namespace Engine.Modely
{
    public class ProcentaPředmětů
    {
        public int ID { get; }
        public int Procenta { get; }

        public ProcentaPředmětů(int iD, int procenta)
        {
            ID = iD;
            Procenta = procenta;
        }
    }
}
