﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Engine.Modely
{
    public   class MnožstvíPředmětů
    {
        public int IDpředmětu { get;  }
        public int Množství { get;  }

        public MnožstvíPředmětů(int iDpředmětu, int množství)
        {
            IDpředmětu = iDpředmětu;
            Množství = množství;
        }
    }
}
