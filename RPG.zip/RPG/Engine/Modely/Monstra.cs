﻿using System.Collections.Generic;
using Engine.Stavby;
namespace Engine.Modely
{
    public class Monstra : Žijící_entita
    {
        private readonly List<ProcentaPředmětů> _bratelné = new List<ProcentaPředmětů>();
        
        public int ID {  get; }
        public string JménoObrázku { get; }
       
        public int OdměnaZkušenosti { get; }
        public Monstra(int id,string jméno, string jménoObrázku, int maximálníŽivoty,HerníPředměty aktuálníZbraň , int odměnaZkušenosti, int zlatky) :
            base(jméno, maximálníŽivoty, maximálníŽivoty, zlatky)
        {
            ID = id;
            JménoObrázku = jménoObrázku;
            AktuálníZbraň = aktuálníZbraň;
            OdměnaZkušenosti = odměnaZkušenosti;
        }
        public void PřidatPředmětDoBratelné(int id, int procenta)
        {
            _bratelné.RemoveAll(pr => pr.ID == id);

            _bratelné.Add(new ProcentaPředmětů(id, procenta));
        }
        public Monstra DostatNovouInstanci()
        {
            Monstra newMonstra =
                new Monstra(ID, Jméno, JménoObrázku, MaximálníŽivoty, AktuálníZbraň, OdměnaZkušenosti, Zlatky);
            foreach(ProcentaPředmětů procentaPředmětů in _bratelné)
            {
                newMonstra.PřidatPředmětDoBratelné(procentaPředmětů.ID, procentaPředmětů.Procenta);
                if(RngGenerátor.HodnotaMezi(1, 100) <= procentaPředmětů.Procenta)
                {
                    newMonstra.PřidatPředmětDoInventáře(Stavba_Předmětů.VytvořitHerníPředmět(procentaPředmětů.ID));
                }
            }
            return newMonstra;
        }
    
    
    }
}
