﻿namespace Engine.Modely
{
    public class Monstra : Žijící_entita
    {
        public string JménoObrázku { get; }
       
        public int OdměnaZkušenosti { get; }
        public Monstra(string jméno, string jménoObrázku, int maximálníŽivoty, int aktuálníŽivoty, int odměnaZkušenosti, int zlatky) :
            base(jméno, maximálníŽivoty, aktuálníŽivoty, zlatky)
        {
            JménoObrázku = $"/Engine;component/Obrázky/Monstra/{jménoObrázku}";
            OdměnaZkušenosti = odměnaZkušenosti;
        }
    }
}
