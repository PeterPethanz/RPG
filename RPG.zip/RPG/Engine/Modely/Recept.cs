﻿using System.Collections.Generic;
using System.Linq;

namespace Engine.Modely
{
    public class Recept
    {
        public int ID { get; }
        public string Jméno { get; }
        public List<MnožstvíPředmětů> Ingredience { get; } = new List<MnožstvíPředmětů>();
        public List<MnožstvíPředmětů> KonečnýPředmět { get; } = new List<MnožstvíPředmětů>();

        public Recept(int iD, string jméno)
        {
            ID = iD;
            Jméno = jméno;
            
        }
        public void PřidatIngredienci(int iDPředmětu, int množství)
        {
            if(!Ingredience.Any(ing => ing.IDpředmětu == iDPředmětu))
            {
                Ingredience.Add(new MnožstvíPředmětů(iDPředmětu, množství));
            }
        }
        public void PřidatKonečnýPředmět(int iDPředmětu, int množství)
        {
            if(!KonečnýPředmět.Any(ing => ing.IDpředmětu == iDPředmětu))
            {
                KonečnýPředmět.Add(new MnožstvíPředmětů(iDPředmětu, množství));
            }
        }
    
    }
}
