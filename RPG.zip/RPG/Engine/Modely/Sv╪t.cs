﻿using System.Collections.Generic;

namespace Engine.Modely
{
    public class Svět
    {
        private readonly List<Lokace> _lokace = new List<Lokace>();

        internal void PřidatLokaci(Lokace lokace)
        {
            _lokace.Add(lokace); 
        }
        public Lokace LokaceNA(int souřadniceX, int souřadniceY)
        {
            foreach(Lokace lok in _lokace)
            {
                if (lok.SouřadniceX == souřadniceX && lok.SouřadniceY == souřadniceY)
                {
                    return lok;
                }
            
            }
            return null;
        }
    }

}
