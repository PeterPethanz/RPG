﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Engine.Modely;

namespace Engine.Stavby
{
    public static class Stavba_Obchodníka
    {
        private static readonly List<Obchodník> _obchodníci = new List<Obchodník>();

        static Stavba_Obchodníka()
        {   //Obchodníci a jejich inventář
            Obchodník Babka = new Obchodník("Babka Kořenářka");
            Babka.PřidatPředmětDoInventáře(Stavba_Předmětů.VytvořitHerníPředmět(1001));
            Babka.PřidatPředmětDoInventáře(Stavba_Předmětů.VytvořitHerníPředmět(3001));
            Babka.PřidatPředmětDoInventáře(Stavba_Předmětů.VytvořitHerníPředmět(3001));
            Babka.PřidatPředmětDoInventáře(Stavba_Předmětů.VytvořitHerníPředmět(3002));
            Babka.PřidatPředmětDoInventáře(Stavba_Předmětů.VytvořitHerníPředmět(3002));
            Babka.PřidatPředmětDoInventáře(Stavba_Předmětů.VytvořitHerníPředmět(3003));
            Babka.PřidatPředmětDoInventáře(Stavba_Předmětů.VytvořitHerníPředmět(3003));

            Obchodník Druid = new Obchodník("Druid Michalovič");
            Druid.PřidatPředmětDoInventáře(Stavba_Předmětů.VytvořitHerníPředmět(1001));
            Druid.PřidatPředmětDoInventáře(Stavba_Předmětů.VytvořitHerníPředmět(8001));
            Druid.PřidatPředmětDoInventáře(Stavba_Předmětů.VytvořitHerníPředmět(8002));

            Obchodník Obchodíček = new Obchodník("Obchodník Julius");
            Obchodíček.PřidatPředmětDoInventáře(Stavba_Předmětů.VytvořitHerníPředmět(1001));

            Obchodník GoblinHanz = new Obchodník("Goblin Hanz");
            GoblinHanz.PřidatPředmětDoInventáře(Stavba_Předmětů.VytvořitHerníPředmět(1001));

            Obchodník Hnědovous = new Obchodník("Hnědovous");
            Hnědovous.PřidatPředmětDoInventáře(Stavba_Předmětů.VytvořitHerníPředmět(1001));

            Obchodník Begolas = new Obchodník("Begolas");
            Begolas.PřidatPředmětDoInventáře(Stavba_Předmětů.VytvořitHerníPředmět(1001));

            //příkaz na vytvoření obchodníka
            PřidatObchodníkaDoListu(Babka);
            PřidatObchodníkaDoListu(Druid);
            PřidatObchodníkaDoListu(Obchodíček);
            PřidatObchodníkaDoListu(GoblinHanz);
            PřidatObchodníkaDoListu(Hnědovous);
            PřidatObchodníkaDoListu(Begolas);
        }
        //příkaz na dostáí obchodníka na lokaci
        public static Obchodník DostatObchodníkaPodleJména(string jméno)
        {
            return _obchodníci.FirstOrDefault(o => o.Jméno == jméno);
        }
        private static void PřidatObchodníkaDoListu(Obchodník obchodník)
        {
            if(_obchodníci.Any(o => o.Jméno == obchodník.Jméno))
            {
                throw new ArgumentException($"Tady už je obchdník jménem {obchodník.Jméno}");
            }
            _obchodníci.Add(obchodník);
        }
    }
}
