﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml;
using Engine.Modely;
using Engine.Sdílené;

namespace Engine.Stavby
{
    public static class Stavba_Obchodníka
    {
        private const string GAME_DATA_FILENAME = "\\HerníData\\Obchodníci.xml";
        private static readonly List<Obchodník> _obchodníci = new List<Obchodník>();

        static Stavba_Obchodníka()
        {
            if(File.Exists(GAME_DATA_FILENAME))
            {
                XmlDocument data = new XmlDocument();
                data.LoadXml(File.ReadAllText(GAME_DATA_FILENAME));

                NačístObchodníkyZNodes(data.SelectNodes("/Obchodníci/Obchodník"));
            }
            else
            {
                throw new FileNotFoundException($"Chybí Soubor Dat{GAME_DATA_FILENAME}");
            }
        
        }
        private static void NačístObchodníkyZNodes(XmlNodeList nodes)
        {
            foreach(XmlNode node in nodes)
            {
                Obchodník obchodník =
                    new Obchodník(node.AtributyJakoInt("ID"),
                    node.SelectSingleNode("./Jménoo")?.InnerText ?? "");
                foreach (XmlNode childnode in node.SelectNodes("./PředmětyVInventáři/Předmět"))
                {
                    int množství = childnode.AtributyJakoInt("Množství");
                    for(int i = 0;i < množství;i++)
                    {
                        obchodník.PřidatPředmětDoInventáře(Stavba_Předmětů.VytvořitHerníPředmět(childnode.AtributyJakoInt("ID")));
                    }
                }
                _obchodníci.Add(obchodník);
            }
        }
        //příkaz na dostání obchodníka na lokaci
        public static Obchodník DostatObchodníkaPodleID(int id)
        {
            return _obchodníci.FirstOrDefault(o => o.ID == id);
        }
       
    }
}
