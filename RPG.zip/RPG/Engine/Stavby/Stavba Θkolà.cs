﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Engine.Modely;

namespace Engine.Stavby
{
    public static class Stavba_Úkolů
    {
        private static readonly List<Úkoly> _úkoly = new List<Úkoly>();
        

        static Stavba_Úkolů()
        {   //Archivy úkolů
            List<MnožstvíPředmětů> předmětyKDokončení = new List<MnožstvíPředmětů>();
            List<MnožstvíPředmětů> odměnaPředmět = new List<MnožstvíPředmětů>();

            List<MnožstvíPředmětů> předmětyKDokončení2 = new List<MnožstvíPředmětů>();
            List<MnožstvíPředmětů> odměnaPředmět2 = new List<MnožstvíPředmětů>();

            List<MnožstvíPředmětů> předmětyKDokončení3 = new List<MnožstvíPředmětů>();
            List<MnožstvíPředmětů> odměnaPředmět3 = new List<MnožstvíPředmětů>();

            List<MnožstvíPředmětů> předmětyKDokončení4 = new List<MnožstvíPředmětů>();
            List<MnožstvíPředmětů> odměnaPředmět4 = new List<MnožstvíPředmětů>();

            List<MnožstvíPředmětů> předmětyKDokončení5 = new List<MnožstvíPředmětů>();
            List<MnožstvíPředmětů> odměnaPředmět5 = new List<MnožstvíPředmětů>();

            List<MnožstvíPředmětů> předmětyKDokončení6 = new List<MnožstvíPředmětů>();
            List<MnožstvíPředmětů> odměnaPředmět6 = new List<MnožstvíPředmětů>();

            List<MnožstvíPředmětů> předmětyKDokončení7 = new List<MnožstvíPředmětů>();
            List<MnožstvíPředmětů> odměnaPředmět7 = new List<MnožstvíPředmětů>();

            //Předměty k dokončení a odměny za úkoly
            předmětyKDokončení.Add(new MnožstvíPředmětů(9001, 5));
            odměnaPředmět.Add(new MnožstvíPředmětů(1002, 1));

            předmětyKDokončení2.Add(new MnožstvíPředmětů(9008,10));
            odměnaPředmět2.Add(new MnožstvíPředmětů(1504, 1));

            předmětyKDokončení3.Add(new MnožstvíPředmětů(9009, 6));
            předmětyKDokončení3.Add(new MnožstvíPředmětů(9010, 2));
            odměnaPředmět3.Add(new MnožstvíPředmětů(1003, 1));

            předmětyKDokončení4.Add(new MnožstvíPředmětů(9011, 10));
            předmětyKDokončení4.Add(new MnožstvíPředmětů(9012, 10));
            odměnaPředmět4.Add(new MnožstvíPředmětů(1004, 1));

            předmětyKDokončení5.Add(new MnožstvíPředmětů(9013, 5));
            předmětyKDokončení5.Add(new MnožstvíPředmětů(9014, 3));
            odměnaPředmět5.Add(new MnožstvíPředmětů(1005, 1));

            předmětyKDokončení6.Add(new MnožstvíPředmětů(9016, 1));
            předmětyKDokončení6.Add(new MnožstvíPředmětů(9018, 1));
            předmětyKDokončení6.Add(new MnožstvíPředmětů(9020, 1));

            předmětyKDokončení7.Add(new MnožstvíPředmětů(9003, 4));
            předmětyKDokončení7.Add(new MnožstvíPředmětů(9004, 4));
            
            //Všechny úkoly
            _úkoly.Add(new Úkoly(1, "Zamořená Zahrádka", "Vyvraždi všechny hady v Zahrádce", předmětyKDokončení, 25, 10, odměnaPředmět));
            _úkoly.Add(new Úkoly(2, "Boj s gobliny", "získej gobliní amulety", předmětyKDokončení2, 35, 10, odměnaPředmět2));
            _úkoly.Add(new Úkoly(3, "Vlčí slůj", "Vyčisti Vlčí slůj", předmětyKDokončení3, 30, 15, odměnaPředmět3));
            _úkoly.Add(new Úkoly(4, "Sbírka oblečení", "zabij piráty a sesbírej jejich oblečení", předmětyKDokončení4, 20, 50, odměnaPředmět4));
            _úkoly.Add(new Úkoly(5, "Démoni v akci", "Zmasakruj démony u portálu", předmětyKDokončení5, 100, 10, odměnaPředmět5));
            _úkoly.Add(new Úkoly(6, "Hlavy Božstev", "Přines Begolasovi hlavy Božských Monster", předmětyKDokončení6, 600, 600,odměnaPředmět6));
            _úkoly.Add(new Úkoly(7, "Sběr kamenů", "Zabij pár golemů pro Michaloviče", předmětyKDokončení7, 30, 25, odměnaPředmět7));
        }
        internal static Úkoly ÚkolPodleID(int id)
        { return _úkoly.FirstOrDefault(úkoly => úkoly.ID == id); }
        




    }
}
