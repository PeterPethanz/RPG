﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml;
using Engine.Sdílené;
using Engine.Modely;
using System.IO;

namespace Engine.Stavby
{
    internal static class Stavba_Úkolů
    {
        private const string GAME_DATA_FILENAME = ".\\HerníData\\Úkoly.xml";
        private static readonly List<Úkoly> _úkoly = new List<Úkoly>();


         static Stavba_Úkolů()
        {
            if (File.Exists(GAME_DATA_FILENAME))
            {
                XmlDocument data = new XmlDocument();
                data.LoadXml(File.ReadAllText(GAME_DATA_FILENAME));

                NačístÚkolyZNodes(data.SelectNodes("/Úkoly/Úkol"));
            }
            else
            {
                throw new FileNotFoundException($"Chybí Soubor Dat{GAME_DATA_FILENAME}");
            }
        }
        private static void NačístÚkolyZNodes(XmlNodeList nodes)
        {
            foreach (XmlNode node in nodes)
            {
                //Deklaruje Předměty potřebné k dokončení a konečnou odměnu
                List<MnožstvíPředmětů> předmětyKDokončení = new List<MnožstvíPředmětů>();
                List<MnožstvíPředmětů> odměna = new List<MnožstvíPředmětů>();

                foreach (XmlNode childNode in node.SelectNodes("./PředmětyKDokončení/Předmět"))
                {
                    předmětyKDokončení.Add(new MnožstvíPředmětů(childNode.AtributyJakoInt("ID"),
                        childNode.AtributyJakoInt("Množství")));
                }
                foreach (XmlNode childnode in node.SelectNodes("./Odměna/Předmět"))
                {
                    odměna.Add(new MnožstvíPředmětů(childnode.AtributyJakoInt("ID"),
                        childnode.AtributyJakoInt("Množství")));
                }
                _úkoly.Add(new Úkoly(node.AtributyJakoInt("ID"),
                    node.SelectSingleNode("./Jméno")?.InnerText ?? "",
                    node.SelectSingleNode("./Popis")?.InnerText ?? "",
                    předmětyKDokončení,
                    node.AtributyJakoInt("OdměnaZkušenosti"),
                    node.AtributyJakoInt("OdměnaZlatky"),
                    odměna));
            }
        }
        internal static Úkoly ÚkolPodleID(int id)
        { 
            return _úkoly.FirstOrDefault(úkoly => úkoly.ID == id);
        }
    }
}
