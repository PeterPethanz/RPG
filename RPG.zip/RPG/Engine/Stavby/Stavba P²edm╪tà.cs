﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml;
using Engine.Modely;
using Engine.Akce;
using Engine.Sdílené;

namespace Engine.Stavby
{
    public static  class Stavba_Předmětů
    {
        private const string GAME_DATA_FILENAME = ".\\HerníData\\HerníPředměty.xml";
        private static readonly List<HerníPředměty> _obyčejnéHerníPředměty = new List<HerníPředměty>();

        static  Stavba_Předmětů()
        {   
            if(File.Exists(GAME_DATA_FILENAME))
            {
                XmlDocument data = new XmlDocument();
                data.LoadXml(File.ReadAllText(GAME_DATA_FILENAME));

                NačístPředmětyZeZápisu(data.SelectNodes("HerníPředměty/Zbraně/Zbraň"));
                NačístPředmětyZeZápisu(data.SelectNodes("HerníPředměty/LéčivéPředměty/LéčivýPředmět"));
                NačístPředmětyZeZápisu(data.SelectNodes("HerníPředměty/SmíšenéPředměty/SmíšenýPředmět"));

            }
            else
            {
                throw new FileNotFoundException($"Chybí datový soubor: {GAME_DATA_FILENAME}");
            }
        }
        public static HerníPředměty VytvořitHerníPředmět(int idPředmětu)
        {
            return _obyčejnéHerníPředměty.FirstOrDefault(předmět => předmět.IDpředmětu == idPředmětu)?.Klon();
        }
        public static string JménoPředmětu(int iDPředmětu)
        {
            return _obyčejnéHerníPředměty.FirstOrDefault(i => i.IDpředmětu == iDPředmětu)?.Jméno ?? "";
        }
        private static void NačístPředmětyZeZápisu(XmlNodeList nodes)
        {
           if(nodes == null)
            {
                return;
            }
            foreach(XmlNode node in nodes)
            {
                HerníPředměty.KategoriePředmětů kategoriePředmětů = UrčitKategoriiPředmětů(node.Name);
                HerníPředměty herníPředměty =
                    new HerníPředměty(kategoriePředmětů,
                    node.AtributyJakoInt("ID"),
                    node.AtributyJakoString("Jméno"),
                     node.AtributyJakoInt("Cena"),
                     kategoriePředmětů == HerníPředměty.KategoriePředmětů.Zbraň);
                if(kategoriePředmětů == HerníPředměty.KategoriePředmětů.Zbraň)
                {
                    herníPředměty.Akce =
                        new ZaútočZbraní(herníPředměty,
                        node.AtributyJakoInt("MinimálníPoškození"),
                        node.AtributyJakoInt("MaximálníPoškození"));
                }
                else if(kategoriePředmětů== HerníPředměty.KategoriePředmětů.Použitelné)
                {
                    herníPředměty.Akce =
                        new Léčení(herníPředměty,
                        node.AtributyJakoInt("ŽivotyNaLéčení"));
                }
                _obyčejnéHerníPředměty.Add(herníPředměty);
            }           
        }
        private static HerníPředměty.KategoriePředmětů UrčitKategoriiPředmětů(string druhPředmětu)
        {
            switch(druhPředmětu)
            {
                case "Zbraň":
                    return HerníPředměty.KategoriePředmětů.Zbraň;
                case "LéčivýPředmět":
                    return HerníPředměty.KategoriePředmětů.Použitelné;
                default:
                    return HerníPředměty.KategoriePředmětů.Smíšené;
            }
        }
    }
}
