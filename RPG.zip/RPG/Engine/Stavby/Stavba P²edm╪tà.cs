﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml;
using Engine.Modely;
using Engine.Akce;

namespace Engine.Stavby
{
    public static  class Stavba_Předmětů
    {
        private const string GAME_DATA_FILENAME = ".\\HerníData\\HerníPředměty.xml";
        private static readonly List<HerníPředměty> _obyčejnéHerníPředměty = new List<HerníPředměty>();

        static  Stavba_Předmětů()
        {   
            if(File.Exists(GAME_DATA_FILENAME))
            {
                XmlDocument data = new XmlDocument();
                data.LoadXml(File.ReadAllText(GAME_DATA_FILENAME));

                NačístPředmětyZeZápisu(data.SelectNodes("/HerníPředměty/Zbraně/Zbraň"));
                NačístPředmětyZeZápisu(data.SelectNodes("HerníPředměty/LéčivéPředměty/LéčivýPředmět"));
                NačístPředmětyZeZápisu(data.SelectNodes("HerníPředměty/SmíšenéPředměty/SmíšenýPředmět"));

            }
            else
            {
                throw new FileNotFoundException($"Chybí datový soubor: {GAME_DATA_FILENAME}");
            }
        }
        public static HerníPředměty VytvořitHerníPředmět(int idPředmětu)
        {
            return _obyčejnéHerníPředměty.FirstOrDefault(předmět => předmět.IDpředmětu == idPředmětu)?.Klon();
        }
        public static string JménoPředmětu(int iDPředmětu)
        {
            return _obyčejnéHerníPředměty.FirstOrDefault(i => i.IDpředmětu == iDPředmětu)?.Jméno ?? "";
        }
        private static void NačístPředmětyZeZápisu(XmlNodeList nodes)
        {
           if(nodes == null)
            {
                return;
            }
            foreach(XmlNode node in nodes)
            {
                HerníPředměty.KategoriePředmětů kategoriePředmětů = UrčitKategoriiPředmětů(node.Name);
                HerníPředměty herníPředměty =
                    new HerníPředměty(kategoriePředmětů,
                    DostatXmlAtributyJakoInt(node, "ID"),
                    DostatXmlAtributyJakoString(node, "Jméno"),
                     DostatXmlAtributyJakoInt(node, "Cena"),
                     kategoriePředmětů == HerníPředměty.KategoriePředmětů.Zbraň);
                if(kategoriePředmětů == HerníPředměty.KategoriePředmětů.Zbraň)
                {
                    herníPředměty.Akce =
                        new ZaútočZbraní(herníPředměty,
                        DostatXmlAtributyJakoInt(node, "MinimálníPoškození"),
                        DostatXmlAtributyJakoInt(node, "MaximálníPoškození"));
                }
                else if(kategoriePředmětů== HerníPředměty.KategoriePředmětů.Použitelné)
                {
                    herníPředměty.Akce =
                        new Léčení(herníPředměty,
                        DostatXmlAtributyJakoInt(node, "ŽivotyNaLéčení"));
                }
                _obyčejnéHerníPředměty.Add(herníPředměty);
            }           
        }
        private static HerníPředměty.KategoriePředmětů UrčitKategoriiPředmětů(string druhPředmětu)
        {
            switch(druhPředmětu)
            {
                case "Zbraň":
                    return HerníPředměty.KategoriePředmětů.Zbraň;
                case "LéčivýPředmět":
                    return HerníPředměty.KategoriePředmětů.Použitelné;
                default:
                    return HerníPředměty.KategoriePředmětů.Smíšené;
            }
        }
        private static int DostatXmlAtributyJakoInt(XmlNode node, string jménoAtributu)
        {
            return Convert.ToInt32(DostatXmlAtributy(node, jménoAtributu));
        }
        private static string DostatXmlAtributyJakoString(XmlNode node, string jménoAtributu)
        {
            return DostatXmlAtributy(node, jménoAtributu);
        }
        private static string DostatXmlAtributy(XmlNode node, string jménoAtributu)
        {
            XmlAttribute attribute = node.Attributes[jménoAtributu];
            if(attribute == null)
            {
                throw new ArgumentException($"Atribut {jménoAtributu} neexistuje.");
            }
            return attribute.Value;
        }
        private static void PostavSmíšenýPředmět(int id, string jméno, int cena)
        {
            _obyčejnéHerníPředměty.Add(new HerníPředměty(HerníPředměty.KategoriePředmětů.Smíšené, id, jméno, cena));
        }
        private static void PostavZbraň(int id, string jméno, int cena, int minimálníPoškození, int maximálníPoškození)
        {
            HerníPředměty zbraň = new HerníPředměty(HerníPředměty.KategoriePředmětů.Zbraň, id, jméno, cena, true);
            zbraň.Akce = new ZaútočZbraní(zbraň, minimálníPoškození, maximálníPoškození);
            _obyčejnéHerníPředměty.Add(zbraň);
        }
        private static void PostavLéčivýPředmět(int id, string jméno, int cena, int životyNaléčení)
        {
            HerníPředměty předměty = new HerníPředměty(HerníPředměty.KategoriePředmětů.Použitelné, id, jméno, cena);
            předměty.Akce = new Léčení(předměty, životyNaléčení);
            _obyčejnéHerníPředměty.Add(předměty);

        }
        
    }
}
