﻿using System.Collections.Generic;
using System.Linq;
using Engine.Modely;
using System.Xml;
using System.IO;
using Engine.Sdílené;

namespace Engine.Stavby
{
    public static class Stavba_Monster
    {
        private const string GAME_DATA_FILENAME = ".\\HerníData\\Monstra.xml";

        private static readonly List<Monstra> _základníMonstra = new List<Monstra>();
    
        static Stavba_Monster()
        {
            if(File.Exists(GAME_DATA_FILENAME))
            {
                XmlDocument data = new XmlDocument();
                data.LoadXml(File.ReadAllText(GAME_DATA_FILENAME));

                string rootImagePath =
                    data.SelectSingleNode("/Monstra")
                    .AtributyJakoString("RootImagePath");

                NačístMonstraZNodes(data.SelectNodes("/Monstra/Monstrum"), rootImagePath);
            }
            else
            {
                throw new FileNotFoundException($"Chybí Soubory dat : {GAME_DATA_FILENAME}");
            }
        }
        private static void NačístMonstraZNodes(XmlNodeList nodes, string rootImagePath)
        {
            if (nodes == null)
            {
                return;
            }
            foreach(XmlNode node in nodes)
            {
                Monstra monstra =
                    new Monstra(node.AtributyJakoInt("ID"),
                                node.AtributyJakoString("Jméno"),
                                $".{rootImagePath}{node.AtributyJakoString("JménoObrázku")}",
                                node.AtributyJakoInt("MaximálníŽivoty"),
                                Stavba_Předmětů.VytvořitHerníPředmět(node.AtributyJakoInt("ZbraňID")),
                                node.AtributyJakoInt("OdměnaZkušenosti"),
                                node.AtributyJakoInt("Zlatky"));

                XmlNodeList dropNodes = node.SelectNodes("./Dropy/Drop");
                if(dropNodes != null)
                {
                    foreach(XmlNode dropnode in dropNodes)
                    {
                        monstra.PřidatPředmětDoBratelné(dropnode.AtributyJakoInt("ID"),
                            dropnode.AtributyJakoInt("Procenta"));
                    }
                }
                _základníMonstra.Add(monstra);
            }
        }
        public static Monstra DostatMonstrum(int id)
        {
            return _základníMonstra.FirstOrDefault(m => m.ID == id)?.DostatNovouInstanci();
        }
    }
}
