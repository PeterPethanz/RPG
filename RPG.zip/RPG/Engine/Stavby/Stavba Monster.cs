﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Engine.Modely;

namespace Engine.Stavby
{
    public static class Stavba_Monster
    {
        public static Monstra DostatMonstrum(int monstraID)
        {
            switch(monstraID)
            {
                case 1:
                    Monstra Had =
                        new Monstra("Had", "Had.png", 4, 4, 5, 2);
                    Had.AktuálníZbraň = Stavba_Předmětů.VytvořitHerníPředmět(1501);

                    PřidatKořist(Had, 9001, 25);
                    PřidatKořist(Had, 9002, 75);

                    return Had;

                    case 2:
                    Monstra Golem =
                        new Monstra("Golem", "Golem.png", 15, 15, 8, 3);
                    Golem.AktuálníZbraň = Stavba_Předmětů.VytvořitHerníPředmět(1502);

                    PřidatKořist(Golem, 9003, 25);
                    PřidatKořist(Golem, 9004, 75);
                    return Golem;

                    case 3:
                    Monstra Pavouk =
                        new Monstra("Pavouk", "Pavouk.png", 10, 10, 10, 2);
                    Pavouk.AktuálníZbraň = Stavba_Předmětů.VytvořitHerníPředmět(1503);

                    PřidatKořist(Pavouk, 9005, 25);
                    PřidatKořist(Pavouk, 9006, 75);
                    return Pavouk;
                    
                case 4:
                    Monstra Goblin =
                    new Monstra("Goblin", "Goblin.png", 10 , 6 , 6 , 8);
                    Goblin.AktuálníZbraň = Stavba_Předmětů.VytvořitHerníPředmět(1504);

                    PřidatKořist(Goblin, 9007, 80);
                    PřidatKořist(Goblin, 9008, 20);
                    PřidatKořist(Goblin, 1504, 1);
                    return Goblin;
                    
                case 5:
                    Monstra Vlk =
                    new Monstra("Vlk", "Vlk.jpg", 8, 5, 5, 6);
                    Vlk.AktuálníZbraň = Stavba_Předmětů.VytvořitHerníPředmět(1505);

                    PřidatKořist(Vlk, 9009, 90);
                    PřidatKořist(Vlk, 9010, 10);
                    return Vlk;
                    
                case 6:
                    Monstra Pirát =
                    new Monstra("Pirát", "Pirát.jpg", 10, 10, 6, 10);
                    Pirát.AktuálníZbraň = Stavba_Předmětů.VytvořitHerníPředmět(1506);

                    PřidatKořist(Pirát, 9011, 50);
                    PřidatKořist(Pirát, 9012, 50);
                    return Pirát;

                    case 7:
                    Monstra démon =
                    new Monstra("Démon", "démon.png", 20, 20, 20, 20);
                    démon.AktuálníZbraň = Stavba_Předmětů.VytvořitHerníPředmět(1507);

                    PřidatKořist(démon, 9013, 20);
                    PřidatKořist(démon, 9014, 20);
                    PřidatKořist(démon, 1507, 1);
                    return démon;
                
                case 8:
                    Monstra Mhad =
                        new Monstra("Hellef", "Matka Hadů.jpg", 100, 100, 100, 100);
                    Mhad.AktuálníZbraň = Stavba_Předmětů.VytvořitHerníPředmět(1508);

                    PřidatKořist(Mhad, 9016, 100);
                    PřidatKořist(Mhad, 9015, 100);
                    PřidatKořist(Mhad, 1508, 1);
                    return Mhad;

                    case 9:
                        Monstra Kgolem =
                        new Monstra("Al-Khazam", "golem king.png", 200, 200, 200,200);
                    Kgolem.AktuálníZbraň = Stavba_Předmětů.VytvořitHerníPředmět(1509);

                    PřidatKořist(Kgolem, 9017, 100);
                    PřidatKořist(Kgolem,9018, 100);
                    PřidatKořist(Kgolem, 1509, 1);

                    return Kgolem;

                    case 10:
                    Monstra Kdémon =
                    new Monstra("Meownar", "demon king.png", 300, 300, 300, 300);
                    Kdémon.AktuálníZbraň = Stavba_Předmětů.VytvořitHerníPředmět(1510);

                    PřidatKořist(Kdémon, 9019, 100);
                    PřidatKořist(Kdémon, 9020, 100);
                    PřidatKořist(Kdémon, 1510, 1);
                    return Kdémon;

                case 11:
                    Monstra Kgoblin =
                        new Monstra("Opezl", "Kgoblin.jpg", 80, 80, 80, 80);
                    Kgoblin.AktuálníZbraň = Stavba_Předmětů.VytvořitHerníPředmět(1511);

                    PřidatKořist(Kgoblin, 9021, 40);
                    PřidatKořist(Kgoblin, 9022, 100);
                    PřidatKořist(Kgoblin, 1511, 1);
                    return Kgoblin;
                        


                default:
                    throw new ArgumentException(string.Format("DruhMonstra '{0}' neexistuje", monstraID));


            }
        }
    private static void PřidatKořist(Monstra monstra, int iDpředmětu, int procenta)
        {
            if (RngGenerátor.HodnotaMezi(1, 100) <= procenta)
            {
                monstra.Inventář.Add(Stavba_Předmětů.VytvořitHerníPředmět(iDpředmětu));
            }
        }

    }
}
