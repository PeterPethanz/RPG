﻿using System.Collections.Generic;
using System.Linq;
using Engine.Modely;
using Engine.Akce;

namespace Engine.Stavby
{
    public static  class Stavba_Předmětů
    {
        private static List<HerníPředměty> _obyčejnéHerníPředměty = new List<HerníPředměty>();

        static  Stavba_Předmětů()
        {   //Zbraně nijak zbláštní
            PostavZbraň(1001, "Větev", 1, 1, 2);
            PostavZbraň(1002, "Starý Meč", 5, 10, 3);
            PostavZbraň(1004, "Tesák vlka", 3, 11, 5);
            PostavZbraň(1005, "Hnědovousova šavle", 13, 5, 10);
            PostavZbraň(1006, "démoní dýka", 20, 20, 20);
            //Zbraně monster
            PostavZbraň(1501, "Hadí Tesáky", 0, 0, 4);
            PostavZbraň(1502, "Obří Balvan", 0, 0, 8);
            PostavZbraň(1503, "Pavoučí Kusadla", 0, 0, 3);
            PostavZbraň(1504, "Gobliní Meč", 0, 0, 10);
            PostavZbraň(1505, "Vlčí Tlapa", 0, 0, 6);
            PostavZbraň(1506, "Pirátská Dýka", 0, 0, 6);
            PostavZbraň(1507, "Meč Duší", 20, 0, 15);
            //Zbraně Bossů
            PostavZbraň(1508, "Zhouba Hellefa", 150, 10, 100);
            PostavZbraň(1509, "Kladivo Al-Khazama", 150, 20, 200);
            PostavZbraň(1510, "Dráp Meownara", 0, 0, 300);
            PostavZbraň(1511, "Palice Opezla", 80, 5, 80);
            //Léčivé Předměty


            //předměty Padající z Mobů
            PostavSmíšenýPředmět(9001, "Hadí Zub", 1);
            PostavSmíšenýPředmět(9002, "Hadí Kůže", 2);

            PostavSmíšenýPředmět(9003, "Úlomek Kamene", 2);
            PostavSmíšenýPředmět(9004, "Kamenné Srdce", 8);

            PostavSmíšenýPředmět(9005, "Pavoučí Kusadla", 1);
            PostavSmíšenýPředmět(9006, "Pavoučí Hedvábí", 3);

            PostavSmíšenýPředmět(9007, "Gobliní Tunika", 5);
            PostavSmíšenýPředmět(9008, "Gobliní Amulet", 6);

            PostavSmíšenýPředmět(9009,"Vlčí kůže", 4);
            PostavSmíšenýPředmět(9010, "Vlčí Tesák", 8);

            PostavSmíšenýPředmět(9011, "Pirátský klobouk", 2);
            PostavSmíšenýPředmět(9012, "Dřevěná noha", 1);

            PostavSmíšenýPředmět(9013, "Démoní korunka", 10);
            PostavSmíšenýPředmět(9014, "Démoní Drápy", 20);

            PostavSmíšenýPředmět(9015, "Kůže krále Hadů", 100);
            PostavSmíšenýPředmět(9016, "Hlava Hellefa", 100);

            PostavSmíšenýPředmět(9017, "Drahokam Krále Golemů", 200);
            PostavSmíšenýPředmět(9018, "Hlava Al-Khazama", 200);

            PostavSmíšenýPředmět(9019, "Koruna Krále démonů", 300);
            PostavSmíšenýPředmět(9020, "Hlava Meownara", 300);

            PostavSmíšenýPředmět(9021, "Žezlo gobliního krále", 150);
            PostavSmíšenýPředmět(9022, "Hlava Opezla", 0);






        }
        public static HerníPředměty VytvořitHerníPředmět(int idPředmětu)
        {
            return _obyčejnéHerníPředměty.FirstOrDefault(předmět => předmět.IDpředmětu == idPředmětu)?.Klon();
        }
        private static void PostavSmíšenýPředmět(int id, string jméno, int cena)
        {
            _obyčejnéHerníPředměty.Add(new HerníPředměty(HerníPředměty.KategoriePředmětů.Smíšené, id, jméno, cena));
        }
        private static void PostavZbraň(int id, string jméno, int cena, int minimálníPoškození, int maximálníPoškození)
        {
            HerníPředměty zbraň = new HerníPředměty(HerníPředměty.KategoriePředmětů.Zbraň, id, jméno, cena, true);
            zbraň.Akce = new ZaútočZbraní(zbraň, minimálníPoškození, maximálníPoškození);
            _obyčejnéHerníPředměty.Add(zbraň);
        }
        private static void PostavLéčivýPředmět(int id, string jméno, int cena, int životyNaléčení)
        {
            HerníPředměty předměty = new HerníPředměty(HerníPředměty.KategoriePředmětů.Spotřebné, id, jméno, cena);
            předměty.Akce = new Léčit(předměty, životyNaléčení);
            _obyčejnéHerníPředměty.Add(předměty);

        }
    
    }
}
