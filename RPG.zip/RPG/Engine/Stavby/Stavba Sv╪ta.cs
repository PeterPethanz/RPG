﻿using System.IO;
using System.Xml;
using Engine.Modely;
using Engine.Sdílené;



namespace Engine.Stavby
{
    internal static class Stavba_Světa
    {
        private const string GAME_DATA_FILENAME = ".\\HerníData\\Lokace.xml";
        internal static Svět VytvořitSvět()
        {
            Svět svět = new Svět();

            if(File.Exists(GAME_DATA_FILENAME))
            {
                XmlDocument data = new XmlDocument();
                data.LoadXml(File.ReadAllText(GAME_DATA_FILENAME));

                string rootImagePath =
                    data.SelectSingleNode("/MnožstvíLokací")
                    .AtributyJakoString("RootImagePath");

                NačístLokaceZNodes(svět,
                    rootImagePath,
                    data.SelectNodes("/MnožstvíLokací/Lokace"));
            }
            else
            {
                throw new FileNotFoundException($"Chybějící soubory dat : {GAME_DATA_FILENAME}");
            }
            return svět;
        }
        private static void NačístLokaceZNodes(Svět svět, string rootImagePath, XmlNodeList nodes)
        {
            if(nodes == null)
            {
                return;
            }
            foreach(XmlNode node in nodes)
            {
                Lokace lokace =
                    new Lokace(node.AtributyJakoInt("X"),
                               node.AtributyJakoInt("Y"),
                               node.AtributyJakoString("Jméno"),
                               node.SelectSingleNode("./Popis")?.InnerText ?? "",
                               $".{rootImagePath}{node.AtributyJakoString("JménoObrázku")}");

                PřidatMonstra(lokace, node.SelectNodes("./Monstra/Monstrum"));
                PřidatÚkoly(lokace, node.SelectNodes("./Úkoly/Úkol"));
                PřidatObchodníka(lokace, node.SelectSingleNode("./Obchodník"));

                svět.PřidatLokaci(lokace);
            }
        }
        private static void PřidatMonstra(Lokace lokace, XmlNodeList monstra)
        {
            if(monstra == null)
            {
                return;
            }
            foreach(XmlNode monstrumNode in monstra)
            {
                lokace.PřidatMonstra(monstrumNode.AtributyJakoInt("ID"),
                    monstrumNode.AtributyJakoInt("Procenta"));
            }
        }
        private static void PřidatÚkoly(Lokace lokace, XmlNodeList úkoly)
        {
            if(úkoly == null)
            {
                return;
            }
            foreach(XmlNode úkolNode in úkoly)
            {
                lokace.ÚkolyZdeKDispozici.Add(Stavba_Úkolů.ÚkolPodleID(úkolNode.AtributyJakoInt("ID")));
            }
        }
        private static void PřidatObchodníka(Lokace lokace, XmlNode obchodníkZde)
        {
            if(obchodníkZde == null)
            {   
                return;
            }
            lokace.ObchodníkZde =
                Stavba_Obchodníka.DostatObchodníkaPodleID(obchodníkZde.AtributyJakoInt("ID"));
        
        }
    }
}
