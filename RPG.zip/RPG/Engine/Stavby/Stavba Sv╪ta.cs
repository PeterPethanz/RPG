﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Engine.Modely;



namespace Engine.Stavby
{
    internal static class Stavba_Světa
    {
        internal static Svět VytvořitSvět()
        {
            Svět novýSvět = new Svět();
            //lokace směr východ
            novýSvět.PřidatLokaci(-2, -1, "Mohutný Dub", "Mohutný Dub a okolo něj skupinka Golemů.", "Starý Strom.png");
            novýSvět.LokaceNA(-2, -1).PřidatMonstra(2, 100);
            novýSvět.PřidatLokaci(-1, -1, "Chatrč Druida Michaloviče", "Alkoholický Michalovič, táhne z něj chlast... Ale dělá výborné rumové pralinky.", 
                "Druidova Chatrč.png");
            novýSvět.LokaceNA(-1, -1).ObchodníkZde = Stavba_Obchodníka.DostatObchodníkaPodleJména("Druid Michalovič");
            novýSvět.LokaceNA(-1, -1).ÚkolyZdeKDispozici.Add(Stavba_Úkolů.ÚkolPodleID(7));
            novýSvět.LokaceNA(-1, -1).ÚkolyZdeKDispozici.Add(Stavba_Úkolů.ÚkolPodleID(3));
            novýSvět.PřidatLokaci(-3, -1, "Vlčí sluj", "Doupě vlků ve kterém čeká hodně ostrých zubů.", "Sluj.png");
            novýSvět.LokaceNA(-3, -1).PřidatMonstra(5, 10);


            //střed mapy
            novýSvět.PřidatLokaci(0, 0, "Smrtící Fontána", "Malebná Fontána plná překvapení... a mrtvých krys...",
                "Fontána.png");
            //směr západ
            novýSvět.PřidatLokaci(1, 0, "Zrádný les", "Pro arachnofobika je toto skvělá příležitost, jak přemoci svůj strach.", "Zrádný Les.png");
            novýSvět.LokaceNA(1, 0).PřidatMonstra(3, 100);
            novýSvět.PřidatLokaci(2, 0, "Lovec Begolas", "Elvský lovec Begolas, Má spadeno Na nejmocnější Monstra", "Begolas.png");
            novýSvět.LokaceNA(2, 0).ObchodníkZde = Stavba_Obchodníka.DostatObchodníkaPodleJména("Begolas");
            novýSvět.LokaceNA(2, 0).ÚkolyZdeKDispozici.Add(Stavba_Úkolů.ÚkolPodleID(6));
            novýSvět.PřidatLokaci(3, 0, "Hora Al-Khazaman", "Král všech golemů. Poraz ho a staň se slavným.", "Hora.png");
            novýSvět.LokaceNA(3, 0).PřidatMonstra(9, 1);
            //směr sever
            novýSvět.PřidatLokaci(0, 1, "Babčino Sídlo", "Otrhaná chaloupka plná kouzelných bylinek... alespoň tak se to říká... Bábi popravdě ujíždí na houbách.", "Chatka Babky.png");
            novýSvět.LokaceNA(0, 1).ÚkolyZdeKDispozici.Add(Stavba_Úkolů.ÚkolPodleID(1));
            novýSvět.LokaceNA(0, 1).ObchodníkZde = Stavba_Obchodníka.DostatObchodníkaPodleJména("Babka Kořenářka");
            novýSvět.PřidatLokaci(0, 2, "Zahrádka", "Zarostlá zahrádka plná hadů, dříve proslulá pro svou hojnost .", "Zahrádka.png");
            novýSvět.LokaceNA(0, 2).PřidatMonstra(1, 100);
            novýSvět.PřidatLokaci(0, 3, "Starý Skleník", "Žije zde Král Hadů... není moc nadšený, že tě vidí","Skleník.jpg");
            novýSvět.LokaceNA(0, 3).PřidatMonstra(8, 1);
            //směr jih
            novýSvět.PřidatLokaci(0, -1, "Tvůj Domov", "Tvé úžasné obydlí, máš i vlastního Goblina... teda umh... spoiler.", "Tvůj Domov.png");
            novýSvět.PřidatLokaci(0, -2, "Goblin Hanz", "Hanz, všestraný smradlavý společník. koupí a prodá cokoliv... Jen mezi námi, Je to Goblin.", "Goblin Hanz.png");
            novýSvět.LokaceNA(0, -2).ObchodníkZde = Stavba_Obchodníka.DostatObchodníkaPodleJména("Goblin Hanz");
            novýSvět.LokaceNA(0, -2).ÚkolyZdeKDispozici.Add(Stavba_Úkolů.ÚkolPodleID(2));
            novýSvět.PřidatLokaci(0, -3, "Smradlavá díra", "Díra která se dokáže smradem rovnat Druidovo dechu... A jako malý bonus je plná Goblinů. Možná to je Hanzova rodina?", "Jeskyně1.png");
            novýSvět.LokaceNA(0, -3).PřidatMonstra(4, 5);
            novýSvět.PřidatLokaci(1, -3, "Sál Velkého Goblina", "Trůní sál přerostlého goblina... Má korunu, asi je to král...", "Trůn.jpg");
            novýSvět.LokaceNA(1, -3).PřidatMonstra(11, 1);

            
            //směr jeskyně
            novýSvět.PřidatLokaci(2, 1, "Vstup do jeskyně", "vstup do jeskyně, co tě tam asi čeká?", "Vstup.png");
            novýSvět.PřidatLokaci(2, 2, "Pirátská Tvrz", "Spíše než tvrz... Je to loď v jeskyni plná pirátů.", "PIRÁTSKÁ TVRZ.png");
            novýSvět.LokaceNA(2, 2).PřidatMonstra(6, 50);
            novýSvět.PřidatLokaci(2, 3, "Pirát Hnědovous", "Vždy chtěl růžové vousy.", "Hnědovous.jpg");
            novýSvět.LokaceNA(2, 3).ObchodníkZde = Stavba_Obchodníka.DostatObchodníkaPodleJména("Hnědovous");
            novýSvět.LokaceNA(2, 3).ÚkolyZdeKDispozici.Add(Stavba_Úkolů.ÚkolPodleID(4));
            novýSvět.LokaceNA(2, 3).ÚkolyZdeKDispozici.Add(Stavba_Úkolů.ÚkolPodleID(5));
            //ven z jeskyně
            novýSvět.PřidatLokaci(3, 3, "Průrva ven", "Úzká průrva ven z jeskyně", "Vstup.png");
            novýSvět.PřidatLokaci(4, 3, "Démoní Portál", "Ohavní démoni všude kolem", "Portál.jpg");
            novýSvět.LokaceNA(4, 3).PřidatMonstra(7, 50);
            novýSvět.PřidatLokaci(5, 3, "Peklo", "Prošel jsi portálem, před tebou stojí Král Pekla a všech démonů.", "peklo.png");
            novýSvět.LokaceNA(5, 3).PřidatMonstra(10, 1);


            return novýSvět;

            

            

              
            
            
            
            
            
            
            
            
            
            
            
           
            
            
        }
    }
}
