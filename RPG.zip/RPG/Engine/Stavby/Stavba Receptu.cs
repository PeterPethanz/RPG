﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml;
using Engine.Modely;
using Engine.Sdílené;

namespace Engine.Stavby
{
    public static class Stavba_Receptu
    {
        private const string GAME_DATA_FILENAME = ".\\HerníData\\Recepty.xml";
        private static readonly List<Recept> _recepty = new List<Recept>();

        static Stavba_Receptu()
        {
            if(File.Exists(GAME_DATA_FILENAME))
            {
                XmlDocument data = new XmlDocument();
                data.LoadXml(File.ReadAllText(GAME_DATA_FILENAME));

                NačístReceptyZNodes(data.SelectNodes("/Recepty/Recept"));
            }
            else
            {
                throw new FileNotFoundException($"Chybí Soubor Dat{GAME_DATA_FILENAME}");
            }
        }
        private static void NačístReceptyZNodes(XmlNodeList nodes)
        {
            foreach (XmlNode node in nodes)
            {
                Recept recept = new Recept(node.AtributyJakoInt("ID"),
                    node.SelectSingleNode("./Jméno")?.InnerText ?? "");
                foreach (XmlNode childNode in node.SelectNodes("./Ingredience/Předmět"))
                {
                    recept.PřidatIngredienci(childNode.AtributyJakoInt("ID"),
                        childNode.AtributyJakoInt("Množství"));
                }
                foreach (XmlNode childNode in node.SelectNodes("./VýslednýPředmět/Předmět"))
                {
                    recept.PřidatKonečnýPředmět(childNode.AtributyJakoInt("ID"),
                        childNode.AtributyJakoInt("Množství"));
                }
                _recepty.Add(recept);
            }
        }
        public static Recept ReceptPodleID(int id)
        {
            return _recepty.FirstOrDefault(x => x.ID == id);
        }
    }
}
