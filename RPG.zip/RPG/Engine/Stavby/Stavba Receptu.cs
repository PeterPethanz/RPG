﻿using System.Collections.Generic;
using System.Linq;
using Engine.Modely;

namespace Engine.Stavby
{
    public static class Stavba_Receptu
    {
        private static readonly List<Recept> _recepty = new List<Recept>();

        static Stavba_Receptu()
        {
            Recept LéčivýLektvar = new Recept(1, "Léčivý Lektvar");
            LéčivýLektvar.PřidatIngredienci(4001, 1);
            LéčivýLektvar.PřidatIngredienci(3001, 1);
            LéčivýLektvar.PřidatKonečnýPředmět(8003, 1);

            _recepty.Add(LéčivýLektvar);

            Recept SáčekBylinek = new Recept(2, "Sáček Bylinek");
            SáčekBylinek.PřidatIngredienci(3002, 1);
            SáčekBylinek.PřidatIngredienci(3003, 1);
            SáčekBylinek.PřidatKonečnýPředmět(4001, 1);

            _recepty.Add(SáčekBylinek);
        }
        public static Recept ReceptPodleID(int id)
        {
            return _recepty.FirstOrDefault(x => x.ID == id);
        }
    }
}
