﻿using System;
using System.Linq;
using Engine.Modely;
using Engine.Stavby;
using Engine.EventArgs;
using System.Xml;


namespace Engine.Vizuální_Modely
{
    public class Prostředí : ZákladníUpozorněníTřída
    {
        public event EventHandler<ZprávyHryEventArgs> NaZprávuVypiš;

        #region Vlastnosti
        private Hráč _akuálníHráč;
        private Lokace _aktuálníLokace;
        private Monstra _aktuálníMonstrum;
        private Obchodník _aktuálníObchodník;
        public Svět AktuálníSvět { get; set; }
        public Hráč AktuálníHráč 
        {
            get { return _akuálníHráč; }
            set
            {
                if (_akuálníHráč != null)
                {
                    _akuálníHráč.NaAkciProvedeno -= NaAktuálníHráčAkceProvedeno;
                    _akuálníHráč.NaZvýšeníÚrovně -= NaAktuálníZvýšeníÚrovněHráče;
                    _akuálníHráč.NaZabití -= NaAktuálníHráčZabít;
                }
                _akuálníHráč = value;
                
                if(_akuálníHráč != null)
                {
                    _akuálníHráč.NaAkciProvedeno += NaAktuálníHráčAkceProvedeno;
                    _akuálníHráč.NaZvýšeníÚrovně += NaAktuálníZvýšeníÚrovněHráče;
                    _akuálníHráč.NaZabití += NaAktuálníHráčZabít;
                }
            }
            
        }
        public Lokace AktuálníLokace 
        {
            get { return _aktuálníLokace; }
            set
            {
                _aktuálníLokace = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(MáLokaciNaSever));
                OnPropertyChanged(nameof(MáLokaciNaVýchod));
                OnPropertyChanged(nameof(MáLokaciNaZápad));
                OnPropertyChanged(nameof(MáLokaciNaJih));

                DokončiÚkolNALokaci();
                DejHráčiÚkolNaLokaci();
                DostaňMonstrumNaLokaci();

                AktuálníObchodník = AktuálníLokace.ObchodníkZde;
            } 
        }
        public Monstra AktuálníMonstrum
        {
            get { return _aktuálníMonstrum; }
            set
            {if(_aktuálníMonstrum !=null)
                {
                    _aktuálníMonstrum.NaAkciProvedeno -= NaAktuálníMonstrumAkceProvedeno;
                    _aktuálníMonstrum.NaZabití -= NaAktuálníMonstrumZabít;
                }
                

                _aktuálníMonstrum = value;

                if (AktuálníMonstrum !=null)
                {
                    _aktuálníMonstrum.NaAkciProvedeno += NaAktuálníMonstrumAkceProvedeno;
                    _aktuálníMonstrum.NaZabití += NaAktuálníMonstrumZabít;
                    
                    VypišZprávu("");
                    VypišZprávu($"Vydíš {AktuálníMonstrum.Jméno}a");
                }
                OnPropertyChanged();
                OnPropertyChanged(nameof(MáMonstrum));
            }
        }
        
        public Obchodník AktuálníObchodník
        {
            get { return _aktuálníObchodník; }
            set
            {
                _aktuálníObchodník = value;

                OnPropertyChanged();
                OnPropertyChanged(nameof(MáObchodníka));
            }
        }

 
        public bool MáLokaciNaSever =>
        AktuálníSvět.LokaceNA(AktuálníLokace.SouřadniceX, AktuálníLokace.SouřadniceY + 1) != null;
        public bool MáLokaciNaZápad =>
        AktuálníSvět.LokaceNA(AktuálníLokace.SouřadniceX - 1, AktuálníLokace.SouřadniceY) != null;
        public bool MáLokaciNaVýchod =>
        AktuálníSvět.LokaceNA(AktuálníLokace.SouřadniceX + 1, AktuálníLokace.SouřadniceY) != null;
        public bool MáLokaciNaJih =>
        AktuálníSvět.LokaceNA(AktuálníLokace.SouřadniceX, AktuálníLokace.SouřadniceY - 1) != null;

        public bool MáMonstrum => AktuálníMonstrum != null;

        public bool MáObchodníka => AktuálníObchodník != null;
        #endregion
        public Prostředí()
        {
            AktuálníHráč = new Hráč("Peťko", "Bojovník", 0, 10, 10, 1000000);
            
            if (!AktuálníHráč.Zbraně.Any())
            {
                AktuálníHráč.PřidatPředmětDoInventáře(Stavba_Předmětů.VytvořitHerníPředmět(1001));
                AktuálníHráč.PřidatPředmětDoInventáře(Stavba_Předmětů.VytvořitHerníPředmět(8001));
                AktuálníHráč.NaučitRecept(Stavba_Receptu.ReceptPodleID(1));
                AktuálníHráč.NaučitRecept(Stavba_Receptu.ReceptPodleID(2));
            }
            AktuálníSvět = Stavba_Světa.VytvořitSvět();

            AktuálníLokace = AktuálníSvět.LokaceNA(0, 0);
            
        }

        public void PohybSever()
        {
          if(MáLokaciNaSever)
            { AktuálníLokace = AktuálníSvět.LokaceNA(AktuálníLokace.SouřadniceX, AktuálníLokace.SouřadniceY + 1); }
        }
        public void PohybZápad()
        {
           if(MáLokaciNaZápad)
            { AktuálníLokace = AktuálníSvět.LokaceNA(AktuálníLokace.SouřadniceX - 1, AktuálníLokace.SouřadniceY); }
        }
        public void PohybVýchod()
        {
            if(MáLokaciNaVýchod)
            { AktuálníLokace = AktuálníSvět.LokaceNA(AktuálníLokace.SouřadniceX + 1, AktuálníLokace.SouřadniceY); }
        }
        public void PohybJih()
        {
            if(MáLokaciNaJih)
            { AktuálníLokace = AktuálníSvět.LokaceNA(AktuálníLokace.SouřadniceX, AktuálníLokace.SouřadniceY - 1); }
        }
        private void DokončiÚkolNALokaci()
        {
            foreach(Úkoly úkoly in AktuálníLokace.ÚkolyZdeKDispozici)
            {
                StatusÚkolů úkolyKDokončení = AktuálníHráč.Úkoly.FirstOrDefault(ú => ú.ÚkolyHráče.ID == úkoly.ID && !ú.Dokončen);
                if(úkolyKDokončení != null)
                {
                    if(AktuálníHráč.MáVšechnyTytoPředměty(úkoly.PředmětyKDokončení))
                    {
                        foreach(MnožstvíPředmětů množstvíPředmětů in úkoly.PředmětyKDokončení)
                        {
                            for(int i = 0; i < množstvíPředmětů.Množství; i++)
                            {
                                AktuálníHráč.OdstranitPředmětZInventáře(AktuálníHráč.Inventář.First(předmět => předmět.IDpředmětu == množstvíPředmětů.IDpředmětu));
                            }
                        }
                        VypišZprávu("");
                        VypišZprávu($"Dokončil jsi úkol {úkoly.Jméno} ");

                        AktuálníHráč.PřidatZkušenosti(úkoly.OdměnaZkušenosti);
                        VypišZprávu($"Dostal jsi{úkoly.OdměnaZkušenosti} Zkušeností");

                        AktuálníHráč.DostatZlatky(úkoly.OdměnaZlatky);
                        VypišZprávu($"Dostal jsi{úkoly.OdměnaZlatky} Zlatek");

                        foreach(MnožstvíPředmětů množstvíPředmětů in úkoly.OdměnaPředmět)
                        {
                            HerníPředměty předmětOdměna = Stavba_Předmětů.VytvořitHerníPředmět(množstvíPředmětů.IDpředmětu);

                            AktuálníHráč.PřidatPředmětDoInventáře(předmětOdměna);
                            VypišZprávu($"Dostal jsi{předmětOdměna.Jméno}");
                        }

                        úkolyKDokončení.Dokončen = true;
                    }
                    
                }

                
            }
            
        }
        private void DejHráčiÚkolNaLokaci()
        {
            foreach (Úkoly úkoly in AktuálníLokace.ÚkolyZdeKDispozici)
            {
                if (!AktuálníHráč.Úkoly.Any(ú => ú.ÚkolyHráče.ID == úkoly.ID))
                {
                    AktuálníHráč.Úkoly.Add(new StatusÚkolů(úkoly));

                    VypišZprávu("");
                    VypišZprávu($"Dostal jsi úkol {úkoly.Jméno} ");
                    VypišZprávu(úkoly.Popis);

                    VypišZprávu("Vrať se s :");
                    foreach(MnožstvíPředmětů množstvíPředmětů in úkoly.PředmětyKDokončení)
                    {
                        VypišZprávu($" {množstvíPředmětů.Množství} {Stavba_Předmětů.VytvořitHerníPředmět(množstvíPředmětů.IDpředmětu).Jméno}");
                    }
                    VypišZprávu("A na oplátku dostaneš :");
                    VypišZprávu($"{úkoly.OdměnaZkušenosti} zkušeností");
                    VypišZprávu($"{ úkoly.OdměnaZlatky} Zlatek");
                    foreach(MnožstvíPředmětů množstvíPředmětů in úkoly.OdměnaPředmět)
                    {
                        VypišZprávu($"{množstvíPředmětů.Množství}x {Stavba_Předmětů.VytvořitHerníPředmět(množstvíPředmětů.IDpředmětu).Jméno}");
                    }
                }

            }
        }
        private void DostaňMonstrumNaLokaci()
        {
            AktuálníMonstrum = AktuálníLokace.DostatMonstrum();
        }
        public void ZaútočAktuálníMonstrum()
        {
            if (AktuálníHráč.AktuálníZbraň == null)
            {
                return;
            }
            if(AktuálníHráč.AktuálníZbraň==null)
            {
                VypišZprávu("Vyber si Zbraň se kterou chceš útočit...");
                return;
            }
            AktuálníHráč.PoužítAktuálníZbraňNa(AktuálníMonstrum);
            //Další monstrum na lokaci
            if (AktuálníMonstrum.JeMrtvý)
            {
                DostaňMonstrumNaLokaci();
            }
            else
            {
                AktuálníMonstrum.PoužítAktuálníZbraňNa(AktuálníHráč);
            }
        } 
        public void PoužítAktuálníPoužitelné()
        {
            if(AktuálníHráč.AktuálníPoužitelné != null)
            {
                AktuálníHráč.PoužítAktuálníPoužitelné();
            }
        }
        public void VytvořPředmětPoužitím(Recept recept)
        {
            if(AktuálníHráč.MáVšechnyTytoPředměty(recept.Ingredience))
            {
                AktuálníHráč.OdstranitPředmětyZInventáře(recept.Ingredience);
                foreach(MnožstvíPředmětů množstvíPředmětů in recept.KonečnýPředmět)
                {
                    for(int i = 0; i < množstvíPředmětů.Množství; i++)
                    {
                        HerníPředměty konečnýPředmět = Stavba_Předmětů.VytvořitHerníPředmět(množstvíPředmětů.IDpředmětu);
                        VypišZprávu($"Vytvořil jsi jeden {konečnýPředmět.Jméno}");
                        AktuálníHráč.PřidatPředmětDoInventáře(konečnýPředmět);
                        
                    }
                }
            }
            else
            {
                VypišZprávu("Nemáš dostatek potřebných ingrediencí");
                foreach(MnožstvíPředmětů množstvíPředmětů in recept.Ingredience)
                {
                    VypišZprávu($"{množstvíPředmětů.Množství} {Stavba_Předmětů.JménoPředmětu(množstvíPředmětů.IDpředmětu)}");
                }
            }
        }
        private void NaAktuálníHráčAkceProvedeno(object sender, string výsledek)
        {
            VypišZprávu(výsledek);
        }
        private void NaAktuálníMonstrumAkceProvedeno(object sender, string výsledek)
        {
            VypišZprávu(výsledek);
        }
        private void NaAktuálníHráčZabít(object sender, System.EventArgs eventArgs)
            {
                VypišZprávu("");
                VypišZprávu($"Byl jsi zabit.");

                AktuálníLokace = AktuálníSvět.LokaceNA(0, -1);
                AktuálníHráč.KompletníLéčení();
            }
        private void NaAktuálníMonstrumZabít(object sender, System.EventArgs eventArgs)
        {
            VypišZprávu("");
            VypišZprávu($"Porazil jsi {AktuálníMonstrum.Jméno}a.");

            VypišZprávu($"Dostal jsi{AktuálníMonstrum.OdměnaZkušenosti} zkušeností.");
            AktuálníHráč.PřidatZkušenosti(AktuálníMonstrum.OdměnaZkušenosti);

            VypišZprávu($"Dostal jsi {AktuálníMonstrum.Zlatky} zlatek.");
            AktuálníHráč.DostatZlatky(AktuálníMonstrum.Zlatky);

            foreach(HerníPředměty herníPředměty in AktuálníMonstrum.Inventář)
            {
                VypišZprávu($"Dostal jsi{herníPředměty.Jméno}");
                AktuálníHráč.PřidatPředmětDoInventáře(herníPředměty);
            }
        }
        private void NaAktuálníZvýšeníÚrovněHráče(object sender, System.EventArgs eventArgs)
        {
            VypišZprávu($"Právě Jsi Dosáhnul Úrovně {AktuálníHráč.Úroveň}!");
            VypišZprávu($"Tvé životy se trvale zvýšili.");
            AktuálníHráč.KompletníLéčení();
        }
        private void VypišZprávu(string zpráva)
        {
            NaZprávuVypiš?.Invoke(this, new ZprávyHryEventArgs(zpráva));
        }

    }

}
