﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;

namespace Engine
{
    public static class RngGenerátor
    {
        private static readonly RNGCryptoServiceProvider _generátor = new RNGCryptoServiceProvider();

        public static int HodnotaMezi(int minimálníHodnota, int maximálníHodnota)
        {
            byte[] náhodnéČíslo = new byte[1];

            _generátor.GetBytes(náhodnéČíslo);

            double asciiHodnnotaNáhodnéhoCharakteru = Convert.ToDouble(náhodnéČíslo[0]);


            double multiplikátor = Math.Max(0, (asciiHodnnotaNáhodnéhoCharakteru / 255d) - 0.00000000001d);

            int rozsah = maximálníHodnota - minimálníHodnota + 1;

            double náhodnéČísloVRozsahu = Math.Floor(multiplikátor * rozsah);

            return (int) (minimálníHodnota + náhodnéČísloVRozsahu);
        }
    }
}
